package com.example.aws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MAadharTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
